<h4>Client Name: {{$name}} </h4>
<h4>Client E-mail: {{$email}} </h4>
<h4>Client Mobile Number: {{$phone}} </h4>
{{$text}}