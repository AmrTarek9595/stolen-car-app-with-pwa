<template>
    <nav class="navbar navbar-dark  navbar-expand-sm fixed-top" id="mainNav">
          <div class="container">
              <a class="navbar-brand" href="#">
          <img src="public/images/navbar/navbar.png" style="max-width:30%;height:auto;display:block" class="img-responsive" alt="">
        </a>



            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon" style="background-image: url('/images/navbar/hambButton.png')"></span>
            
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
              <ul class="navbar-nav text-uppercase ml-auto">
                   <li class="nav-item">
                  <a class="nav-link js-scroll-trigger" href="/">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link js-scroll-trigger" href="/apply">Apply</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link js-scroll-trigger" href="/inquiry">inquiry</a>
                </li>
             <li class="nav-item">
                  <a class="nav-link js-scroll-trigger" href="/inform">inform</a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
</template>

<script>
export default {

}
</script>

<style>

</style>