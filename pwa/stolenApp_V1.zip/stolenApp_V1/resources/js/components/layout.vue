<template>
<div>

<Nav/>



<router-view></router-view>
<Footer/>
</div>
</template>

<script>
import Nav from "./nav.vue";

import Footer from "./footer.vue";
    export default {
    components:{'Nav':Nav,'Footer':Footer},

    mounted(){
      
    },
    methods:{
    

        
    }
    
    }
</script>
