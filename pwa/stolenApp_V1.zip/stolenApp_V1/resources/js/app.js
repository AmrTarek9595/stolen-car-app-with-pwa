

require('./bootstrap');
import Vue from 'vue';
import Home from './components/home.vue';
import Apply from './components/apply.vue';
import Layout from './components/layout.vue';
import Inquiry from './components/inquiry.vue';
import Inform from './components/inform.vue';
import VueRouter from 'vue-router';
Vue.use(VueRouter);

const router=new VueRouter({
 mode:'history',
    routes:[
        {
            path:'/',
            component:Home
        },
        {
            path:'/apply',
            component:Apply
        },
        {
            path:'/inquiry',
            component:Inquiry
        },
        {
            path:'/inform',
            component:Inform
        }
    ]
});




const app = new Vue({
    el: '.page',
    components:{Layout},
    router
});
