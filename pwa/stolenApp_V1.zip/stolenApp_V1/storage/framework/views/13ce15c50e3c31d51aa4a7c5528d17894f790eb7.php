<h4>Client Name: <?php echo e($name); ?> </h4>
<h4>Client E-mail: <?php echo e($email); ?> </h4>
<h4>Client Mobile Number: <?php echo e($phone); ?> </h4>
<?php echo e($text); ?><?php /**PATH C:\wamp64\www\stolenApp_V1\resources\views/mail.blade.php ENDPATH**/ ?>