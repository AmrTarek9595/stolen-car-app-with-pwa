



    <h1>You are currently not connected to any networks.</h1>
    <FORM>
<INPUT TYPE="button" onClick="history.go(0)" VALUE="Refresh">
</FORM>
<?php /**PATH C:\wamp64\www\stolenApp_V1\resources\views/vendor/laravelpwa/offline.blade.php ENDPATH**/ ?>